# Data erased
Ha ha , you wont find who did this.